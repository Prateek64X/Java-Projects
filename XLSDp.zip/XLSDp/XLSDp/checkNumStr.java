package XLSDp;
import org.apache.commons.lang3.*;
//Dependencies
//String Utils: http://www.java2s.com/Code/Jar/a/Downloadapachecommonslangjar.htm
public class checkNumStr {
    public static void main(String args[]){
        String a = "123";
        String b = "abc";
        System.out.println(Double.parseDouble(b));
    }
}
